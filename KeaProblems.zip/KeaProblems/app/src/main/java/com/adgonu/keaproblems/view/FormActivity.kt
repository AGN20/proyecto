package com.adgonu.keaproblems.view

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.activity.viewModels
import com.adgonu.keaproblems.R
import com.adgonu.keaproblems.databinding.ActivityFormBinding
import com.adgonu.keaproblems.viewmodel.IncidentViewModel
import com.adgonu.keaproblems.viewmodel.UserViewModel

class FormActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFormBinding
    private val incidentViewModel : IncidentViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFormBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        //Setup
        val bundle: Bundle? = intent.extras
        val email = bundle?.getString("email")
        setup(email ?: "")

        //Guardar de datos
        val prefs = getSharedPreferences(getString(R.string.prefs_file), Context.MODE_PRIVATE).edit()
        prefs.putString("email", email)
        prefs.apply()

    }

    private fun setup(email: String){

        title = "Fromulario Incidencias"
        binding.agentView.isFocusable = false
        binding.endDate.isFocusable = false

        binding.refUserView.text = email

        val spinnerG: Spinner = findViewById(R.id.spinnerGrup)
        ArrayAdapter.createFromResource(
            this,
            R.array.grups_array,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinnerG.adapter = adapter
        }

        val spinnerE: Spinner = findViewById(R.id.spinnerEstatus)
        ArrayAdapter.createFromResource(
            this,
            R.array.estatus_array,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinnerE.adapter = adapter
        }

        binding.sendButton.setOnClickListener{
            incidentViewModel.setIncident(
                binding.refUserView.text.toString(),
                binding.titleView.text.toString(),
                binding.agentView.text.toString(),
                binding.spinnerGrup.selectedItem.toString(),
                binding.spinnerEstatus.selectedItem.toString(),
                binding.startDate.text.toString(),
                binding.endDate.text.toString(),
                binding.descriptionMLT.text.toString()
            )
        }

    }
}