package com.adgonu.keaproblems.adapter

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.adgonu.keaproblems.R
import com.adgonu.keaproblems.model.model.IncidentModel

class IncidentViewHolder (view: View): RecyclerView.ViewHolder(view){

    val idText = view.findViewById<TextView>(R.id.idViewR)
    val ownerText = view.findViewById<TextView>(R.id.userViewR)
    val titleText = view.findViewById<TextView>(R.id.titleMLTR)

    fun render(incidentModel: IncidentModel){
        idText.text = incidentModel.id
        ownerText.text = incidentModel.owner
        titleText.text = incidentModel.title
    }

}