package com.adgonu.keaproblems.model.model

data class IncidentModel (
    val id: String = "",
    val grup: String = "",
    val owner: String = "",
    val title: String = "",
    val priority: String = "",
    val estatus: String = "",
    val description: String = "",
    val agent: String = "",
    val dateCreation: String = "",
    val dateEnd: String = ""
    )