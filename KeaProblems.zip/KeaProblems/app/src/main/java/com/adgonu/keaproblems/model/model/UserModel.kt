package com.adgonu.keaproblems.model.model

data class UserModel (
    val email: String = "",
    val name: String = "",
    val grup: String = ""
    )