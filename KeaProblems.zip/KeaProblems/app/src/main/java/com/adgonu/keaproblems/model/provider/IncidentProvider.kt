package com.adgonu.keaproblems.model.provider

import com.adgonu.keaproblems.model.model.IncidentModel
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.firestore.FirebaseFirestore
import com.google.type.Date
import java.io.FileDescriptor

typealias OnIncidentReceived = (incident: IncidentModel) -> Unit

class IncidentProvider {
    companion object {

        private val db = FirebaseFirestore.getInstance()

        fun getUser(email:String, onUserReceived: OnUserReceived){

            db.collection("Incidents").document(email).get().addOnCompleteListener(){ task ->
                if(task.isSuccessful){
                    val document = task.result
                    if(document != null) {
                        if (document.exists()) {
                            var incident = document.toObject(IncidentModel::class.java)
                        }
                    }
                }
            }

        }

        fun setIncident(owner:String, title: String, agent: String, grup: String, estatus: String, startDate: String, endDate: String, description: String){

            db.collection("Incidents").document().set(
                hashMapOf(
                    "owner" to owner,
                    "title" to title,
                    "agent" to agent,
                    "grup" to grup,
                    "estatus" to estatus,
                    "startDate" to startDate,
                    "endDate" to endDate,
                    "description" to description,
                )
            )

        }

    }
}