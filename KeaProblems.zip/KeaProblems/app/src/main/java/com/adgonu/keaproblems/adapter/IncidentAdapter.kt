package com.adgonu.keaproblems.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.adgonu.keaproblems.R
import com.adgonu.keaproblems.databinding.ActivityRegisterBinding.inflate
import com.adgonu.keaproblems.databinding.FragmentIncidentBinding
import com.adgonu.keaproblems.model.model.IncidentModel

class IncidentAdapter(private val dataSet: List<IncidentModel>) : RecyclerView.Adapter<IncidentViewHolder>(){

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): IncidentViewHolder {
        val binding = FragmentIncidentBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return IncidentViewHolder(LayoutInflater.inflate(R.layout.fragment_incident, parent, false))
    }

    override fun onBindViewHolder(holder: IncidentViewHolder, position: Int) {

    }

    override fun getItemCount(): Int {
        return dataSet.size
    }

}