package com.adgonu.keaproblems.view

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AlertDialog
import com.adgonu.keaproblems.R
import com.adgonu.keaproblems.databinding.ActivityAuthBinding
import com.google.firebase.auth.FirebaseAuth


class AuthActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAuthBinding

    override fun onCreate(savedInstanceState: Bundle?) {



        super.onCreate(savedInstanceState)
        binding = ActivityAuthBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        //Setup
        setup()
        session()
    }

    override fun onStart() {
        super.onStart()
        binding.authLayout.visibility = View.VISIBLE
    }

    //Inicio de sesion
    private fun setup(){

        title = "Autentificacion"

        //Funcionalidad del boton registrar
        binding.signUpButton.setOnClickListener{
            if(binding.emailEditText.text.isNotEmpty() && binding.passwordEditText.text.isNotEmpty()){
                FirebaseAuth.getInstance().createUserWithEmailAndPassword(binding.emailEditText.text.toString(),
                    binding.passwordEditText.text.toString()).addOnCompleteListener{
                        if(it.isSuccessful){
                            showRegister(it.result?.user?.email ?: "")
                        }else{
                            showAlert()
                        }
                }
            }
        }

        //Fincionalidad del boton loguearse
        binding.loguinButton.setOnClickListener{
            if(binding.emailEditText.text.isNotEmpty() && binding.passwordEditText.text.isNotEmpty()){
                FirebaseAuth.getInstance().signInWithEmailAndPassword(binding.emailEditText.text.toString(),
                    binding.passwordEditText.text.toString()).addOnCompleteListener{
                    if(it.isSuccessful){
                        showMenu(it.result?.user?.email ?: "")
                    }else{
                        showAlert()
                    }
                }
            }
        }

    }

    private fun session(){

        val prefs = getSharedPreferences(getString(R.string.prefs_file), Context.MODE_PRIVATE)

        val email = prefs.getString("email", null)

        if(email != null){
            binding.authLayout.visibility = View.INVISIBLE
            showMenu(email)
        }

    }

    //Alerta cuando falla la autentificación
    private fun showAlert(){

        val builder = AlertDialog.Builder(this)
        builder.setTitle("Error")
        builder.setMessage("Se a producido un error autentificando al usuario")
        builder.setPositiveButton("Acceptar", null)
        val dialog: AlertDialog = builder.create()
        dialog.show()

    }

    //Navegacion al Menu
    private fun showMenu(email: String){

        val menuIntent = Intent(this, MenuActivity::class.java).apply {
            putExtra("email", email)
        }
        startActivity(menuIntent)

    }

    //Navegacion al Register
    private fun showRegister(email: String){

        val registerIntent = Intent(this, RegisterActivity::class.java).apply {
            putExtra("email", email)
        }
        startActivity(registerIntent)

    }

}