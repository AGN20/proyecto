package com.adgonu.keaproblems.model.provider

import androidx.lifecycle.MutableLiveData
import com.adgonu.keaproblems.model.model.UserModel
import com.adgonu.keaproblems.viewmodel.UserViewModel
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


typealias OnUserReceived = (user: UserModel) -> Unit

class UserProvider{
     companion object {

         private val db = FirebaseFirestore.getInstance()

         fun getUser(email:String, onUserReceived: OnUserReceived){
             db.collection("users").document(email).get().addOnCompleteListener{ task ->
                 if(task.isSuccessful){
                     val document = task.result
                     if(document != null){
                         if(document.exists()){
                             var user = document.toObject(UserModel::class.java)
                             onUserReceived(user!!)
                         }
                     }
                 }
             }
         }

         fun setUser(email:String, name: String, grup: String){

             db.collection("users").document(email).set(
                 hashMapOf(
                     "name" to name,
                     "grup" to grup
                 )
             )

         }

     }
}