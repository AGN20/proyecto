package com.adgonu.keaproblems.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.adgonu.keaproblems.model.model.IncidentModel
import com.adgonu.keaproblems.model.model.UserModel
import com.adgonu.keaproblems.model.provider.IncidentProvider
import com.adgonu.keaproblems.model.provider.UserProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class IncidentViewModel(application: Application) : AndroidViewModel(application) {

    val context = application
    val provider = IncidentProvider
    val IncidentList = MutableLiveData<IncidentModel>()

    fun setIncident(owner:String, title: String, agent: String, grup: String, estatus: String, startDate: String, endDate: String, description: String){
        CoroutineScope(Dispatchers.IO).launch{
            provider.setIncident(owner, title, agent, grup, estatus, startDate, endDate, description)
        }
    }

}