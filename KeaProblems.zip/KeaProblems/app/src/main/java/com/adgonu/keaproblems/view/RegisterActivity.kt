package com.adgonu.keaproblems.view

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import com.adgonu.keaproblems.R
import com.adgonu.keaproblems.databinding.ActivityRegisterBinding
import com.adgonu.keaproblems.viewmodel.UserViewModel
import com.google.firebase.firestore.FirebaseFirestore

class RegisterActivity : AppCompatActivity() {

    private val userViewModel : UserViewModel by viewModels()

    private lateinit var binding: ActivityRegisterBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        //Setup
        val bundle: Bundle? = intent.extras
        val email = bundle?.getString("email")
        setup(email ?: "")

        val spinner: Spinner = findViewById(R.id.spinner)
        ArrayAdapter.createFromResource(
            this,
            R.array.grups_array,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner.adapter = adapter
        }

        setup(email ?: "")

    }

    private fun setup( email: String){

        title = "Inicio"
        binding.emailView.text = email

        binding.createButton.setOnClickListener{
            if(!binding.nameView.text.isEmpty()){
                userViewModel.setUser(email, binding.nameView.text.toString(), binding.spinner.selectedItem.toString())
            }else{
                showNameError()
            }
            showMenu(email)
        }

        binding.cleanButton.setOnClickListener{
            binding.nameView.text.clear()
        }

    }

    private fun showMenu(email: String){

        val menuIntent = Intent(this, MenuActivity::class.java).apply {
            putExtra("email", email)
        }
        startActivity(menuIntent)

    }

    private fun showNameError(){

        val builder = AlertDialog.Builder(this)
        builder.setTitle("Error")
        builder.setMessage("Es necesario que indique un nombre")
        builder.setPositiveButton("Acceptar", null)
        val dialog: AlertDialog = builder.create()
        dialog.show()

    }

}