package com.adgonu.keaproblems.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.adgonu.keaproblems.model.model.UserModel
import com.adgonu.keaproblems.model.provider.OnUserReceived
import com.adgonu.keaproblems.model.provider.UserProvider
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class UserViewModel(application: Application) : AndroidViewModel(application){

    val context = application
    val provider = UserProvider
    val userList = MutableLiveData<UserModel>()

    private val db = FirebaseFirestore.getInstance()


    fun getUser(email:String){
        CoroutineScope(Dispatchers.IO).launch {
            provider.getUser(email) { user ->
                userList.postValue(user)
            }
        }
    }

    fun setUser(email:String, name: String, grup: String){
        CoroutineScope(Dispatchers.IO).launch{
            provider.setUser(email, name, grup)
        }
    }

}